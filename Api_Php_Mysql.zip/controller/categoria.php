<?php

   /* 1ra linea necesaria para recibir y enviar datos tipo JSON */
   header('Content-Type: application/json');

     require_once("../config/conexion.php");
     require_once("../model/Categoria.php");

     /* 2da linea necesaria para recibir y enviar datos tipo JSON */
      $body = json_decode(file_get_contents("php://input"), true);

     $categoria = new Categoria();

     switch ($_GET["op"]) {


        case "ShowAll":
              $datos=$categoria->show_categoria();
              echo json_encode($datos);
        break;



        case"ShowId":
             $datos= $categoria->show_categoria_id($body["cat_id"]);
             echo json_encode($datos);


        break;



        case "Insert":
            $datos = $categoria->create_categoria($body["cat_nom"], $body["cat_descrip"]);
            echo "Registro Correcto";
             
        break;


        case "Update":
            $datos = $categoria->update_categoria($body["cat_id"], $body["cat_nom"], $body["cat_descrip"]);
            echo "Actualización Correcta";
             
        break;


        case "Delete":
            $datos = $categoria->update_estado($body["cat_id"]);
            echo "Registro Eliminado";
             
        break;

        
     }



?>