<?php


class Producto extends Conectar{


  /* TODO: Mostrar todos los registro de Producto */
  public function show_producto(){
    $conectar=parent::Conexion();
    parent::set_names();
    $sql="SELECT *FROM tm_producto WHERE est =1";
    $sql=$conectar->prepare($sql);
    $sql->execute();
    return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
 }



   /* TODO: Mostrar registro de Producto Por Id especifico */
   public function show_producto_id($prod_id){
    $conectar=parent::Conexion();
    parent::set_names();
    $sql="SELECT *FROM tm_producto WHERE est = 1 AND prod_id = ?";
    $sql=$conectar->prepare($sql);
    $sql->bindValue(1, $prod_id);
    $sql->execute();
    return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
   }

 
     /* TODO: Insertar Nuevo Registro desde Frontend */
     public function create_producto($prod_nom, $prod_descrip, $prod_costo, $prod_precio, $prod_stock, $cat_id){
        $conectar=parent::Conexion();
        parent::set_names();
        $sql="INSERT INTO tm_producto (prod_id, prod_nom, prod_descrip, prod_costo, prod_precio, prod_stock, cat_id, est) 
        VALUES (NULL, ?,?,?,?,?,?, '1')";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1, $prod_nom);
        $sql->bindValue(2, $prod_descrip);
        $sql->bindValue(3, $prod_costo);
        $sql->bindValue(4, $prod_precio);
        $sql->bindValue(5, $prod_stock);
        $sql->bindValue(6, $cat_id);
        $sql->execute();
        return $resultado=$sql->fetchAll(PDO::FETCH_ASSOC);
     }



      /* TODO: Actualizar datos del Registro desde Frontend */
      public function update_producto($prod_id, $prod_nom, $prod_descrip, $prod_costo, $prod_precio, $prod_stock, $cat_id, $est){
            $conectar=parent::Conexion();
            parent::set_names(); 

            $sql="UPDATE tm_producto 
                  SET   prod_nom =?,
                        prod_descrip = ?,
                        prod_costo = ?,
                        prod_precio = ?, 
                        prod_stock = ?, 
                        cat_id = ?,
                        est = ? 
                  WHERE prod_id = ?";

            $sql=$conectar->prepare($sql);
            $sql->bindValue(1, $prod_nom);
            $sql->bindValue(2, $prod_descrip);
            $sql->bindValue(3, $prod_costo);
            $sql->bindValue(4, $prod_precio);
            $sql->bindValue(5, $prod_stock);
            $sql->bindValue(6, $cat_id);
            $sql->bindValue(7, $est);
            $sql->bindValue(8, $prod_id);
            $sql->execute();
        
     }



      /* TODO: Actualizar Campo est = 0 (Eliminar de Lista) del Registro Segun prod_id */
      public function update_estado($prod_id){
        $conectar=parent::Conexion();
        parent::set_names(); 
        
        $sql="UPDATE tm_producto 
              SET   est = '0'
              WHERE prod_id = ?";

        $sql=$conectar->prepare($sql);
        $sql->bindValue(1, $prod_id);
        $sql->execute();
    
     }



}




?>