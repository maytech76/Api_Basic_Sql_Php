swal.fire({
    title:'Categoria',
    text: 'Registro Eliminado',
    icon: 'success',
    showConfirmButton: false,
    timer: 1500
});